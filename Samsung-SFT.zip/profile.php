<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Oops!</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Public+Sans">
</head>

<body>
  <h1>The profile page is under construction.</h1>
  <p>This page requires the implementation of an account system, which is not necessary and is too difficult for a prototype. However, this comes with the drawback in that there is no reward system as of current.</p>
  <button onclick="window.location.href = '/index.php'">Press me to return to menu!</button>
</body>

</html>