<?php
    $file = 'textData/markerLocations.txt';
    $lines = count(file($file));
    echo $lines;
?>
