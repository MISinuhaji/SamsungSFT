window.screen.orientation.lock("portrait")
.then(success => console.log(success), 
      failure => console.log(failure))
